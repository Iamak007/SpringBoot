package com.pareek.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	//@Column(name = "uname")
	private String userName;
	private String userPassword;
	private Integer userAge;
	private String userCity;
	private String userEmail;
	private String userGender;
	private String userBirthday;
	private boolean userMarried;
	
	
	@Lob
	private byte[] userPic;


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity, String userEmail,
			String userGender, String userBirthday, boolean userMarried) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userEmail = userEmail;
		this.userGender = userGender;
		this.userBirthday = userBirthday;
		this.userMarried = userMarried;
	}


	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity, String userEmail,
			String userGender, String userBirthday, boolean userMarried, byte[] userPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userEmail = userEmail;
		this.userGender = userGender;
		this.userBirthday = userBirthday;
		this.userMarried = userMarried;
		this.userPic = userPic;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public Integer getUserAge() {
		return userAge;
	}


	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}


	public String getUserCity() {
		return userCity;
	}


	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public String getUserGender() {
		return userGender;
	}


	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}


	public String getUserBirthday() {
		return userBirthday;
	}


	public void setUserBirthday(String userBirthday) {
		this.userBirthday = userBirthday;
	}


	public boolean isUserMarried() {
		return userMarried;
	}


	public void setUserMarried(boolean userMarried) {
		this.userMarried = userMarried;
	}


	public byte[] getUserPic() {
		return userPic;
	}


	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}
	public String getUserPicture() {
		return Base64.encodeBase64String(userPic);
	}


	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", userAge=" + userAge
				+ ", userCity=" + userCity + ", userEmail=" + userEmail + ", userGender=" + userGender
				+ ", userBirthday=" + userBirthday + ", userMarried=" + userMarried + "]";
	}
	
	
/*	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
	}
	
	
	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity, byte[] userPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userPic = userPic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}
	
	public byte[] getUserPic() {
		return userPic;
	}
	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}
	public String getUserPicture() {
		return Base64.encodeBase64String(userPic);
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", userAge=" + userAge
				+ ", userCity=" + userCity + "]";
	}*/
	
	
	
	
	
	
}

